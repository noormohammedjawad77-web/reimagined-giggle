package com.starknetwork.autorespawn;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class AutoRespawnPlugin extends JavaPlugin implements Listener {

    private long delay;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        delay = Math.max(1L, getConfig().getLong("delay-ticks", 1L));
        getServer().getPluginManager().registerEvents(this, this);
    }

    // MONITOR: runs after every other plugin handled the death (drops, messages, stats).
    // The respawn is a normal respawn, so PlayerRespawnEvent still fires for other plugins (e.g. RandomKit).
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (player.hasPermission("autorespawn.bypass")) return;
        getServer().getScheduler().runTaskLater(this, () -> {
            if (player.isOnline() && player.isDead()) {
                player.spigot().respawn();
            }
        }, delay);
    }
}
